Ghidra 12.1.4 linux/arm64 反编译器（预编译，免源码编译）
构建环境: Ubuntu 24.04 arm64, glibc 2.39, g++ 13.3
适用: aarch64 Linux (glibc 发行版), JDK 21+
用法: 解压后把 decompile/sleigh 放入 Ghidra/Features/Decompiler/os/linux_arm_64/
sha256 见同目录 checksums
